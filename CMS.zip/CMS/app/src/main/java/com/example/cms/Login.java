package com.example.cms;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

public class Login extends AppCompatActivity {
    ImageView img;
    Animation top;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        img=(ImageView)findViewById(R.id.imageView);
        top= AnimationUtils.loadAnimation(getApplicationContext(),R.anim.mainlogoanimation);
        img.setAnimation(top);
    }
}